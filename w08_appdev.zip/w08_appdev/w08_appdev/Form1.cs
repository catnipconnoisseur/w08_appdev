﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml.Linq;

namespace w08_appdev
{
    public partial class form_uniqme : Form
    {
        DataTable dt = new DataTable();
        string del = "";

        public form_uniqme()
        {
            InitializeComponent();
        }

        private void form_uniqme_Load(object sender, EventArgs e)
        {
            panel_tshirt.Visible = false;
            panel_shirt.Visible = false;
            panel_pants.Visible = false;
            panel_longpants.Visible = false;
            panel_shoes.Visible = false;
            panel_jewelries.Visible = false;
            panel_others.Visible = false;

            dt.Columns.Add("Item Name");
            dt.Columns.Add("Quantity");
            dt.Columns.Add("Price");
            dt.Columns.Add("Total");
            dgv_cart.DataSource = dt;

            panel_shirt.Visible = false;

            dgv_cart.ReadOnly = true;
            tb_subtotal.Enabled = false;
            tb_total.Enabled = false;
        }

        private void addtocart(string itemname, int price)
        {
            bool check = false;
            int itemqty = 1;

            foreach (DataRow dt in dt.Rows)
            {
                if (dt["Item Name"].ToString() == itemname)
                {
                    check = true;
                    break;
                }
                else
                {
                    check = false;
                }
            }
            if (check == false)
            {
                dt.Rows.Add(itemname, itemqty, price, itemqty * price);
            }
            else if (check == true)
            {
                foreach (DataRow dt in dt.Rows)
                {
                    if (dt["Item Name"].ToString() == itemname)
                    {
                        int currentqty = Convert.ToInt32(dt["Quantity"]);
                        int newqty = currentqty + 1;
                        dt["Quantity"] = newqty;
                        dt["Total"] = newqty * price;
                        break;
                    }
                }
            }
            total();
        }

        private void total()
        {
            int total = 0;
            int subtotal = 0;
            foreach (DataRow dt in dt.Rows)
            {
                subtotal = subtotal + Convert.ToInt32(dt["Total"]);
                total = subtotal + (subtotal / 10);
                tb_subtotal.Text = subtotal.ToString();
                tb_total.Text = total.ToString();
            }
        }

        private void btn_addtshirt1_Click(object sender, EventArgs e)
        {
            int price = 200000;
            string itemname = "Loose Fit Printed T-Shirt";
            addtocart(itemname, price);
        }

        private void btn_addtshirt2_Click(object sender, EventArgs e)
        {
            int price = 350000;
            string itemname = "Oversized Printed T-Shirt";
            addtocart(itemname, price);
        }

        private void btn_addtshirt3_Click(object sender, EventArgs e)
        {
            int price = 380000;
            string itemname = "Boxy-Style T-Shirt";
            addtocart(itemname, price);
        }

        private void btn_addshirt1_Click(object sender, EventArgs e)
        {
            int price = 430000;
            string itemname = "Classic Formal Shirt";
            addtocart(itemname, price);
        }

        private void btn_addshirt2_Click(object sender, EventArgs e)
        {
            int price = 480000;
            string itemname = "Printed Embroidery Shirt";
            addtocart(itemname, price);
        }

        private void btn_addshirt3_Click(object sender, EventArgs e)
        {
            int price = 500000;
            string itemname = "Fit Long Sleeve Shirt";
            addtocart(itemname, price);
        }

        private void btn_addpants1_Click(object sender, EventArgs e)
        {
            int price = 450000;
            string itemname = "Lois Short Jeans";
            addtocart(itemname, price);
        }

        private void btn_addpants2_Click(object sender, EventArgs e)
        {
            int price = 430000;
            string itemname = "Cane Linen Shorts";
            addtocart(itemname, price);
        }

        private void btn_addpants3_Click(object sender, EventArgs e)
        {
            int price = 500000;
            string itemname = "Ultra Comfy Shorts";
            addtocart(itemname, price);
        }

        private void btn_addlongpants1_Click(object sender, EventArgs e)
        {
            int price = 1260000;
            string itemname = "Skinny Cropped Jeans";
            addtocart(itemname, price);
        }

        private void btn_addlongpants2_Click(object sender, EventArgs e)
        {
            int price = 600000;
            string itemname = "Loose Fit High Jeans";
            addtocart(itemname, price);
        }

        private void btn_addlongpants3_Click(object sender, EventArgs e)
        {
            int price = 540000;
            string itemname = "Orbit Cargo Pants";
            addtocart(itemname, price);
        }

        private void btn_addshoes1_Click(object sender, EventArgs e)
        {
            int price = 540000;
            string itemname = "Orbit Cargo Pants";
            addtocart(itemname, price);
        }

        private void btn_addshoes2_Click(object sender, EventArgs e)
        {
            int price = 540000;
            string itemname = "Orbit Cargo Pants";
            addtocart(itemname, price);
        }

        private void btn_addshoes3_Click(object sender, EventArgs e)
        {
            int price = 540000;
            string itemname = "Orbit Cargo Pants";
            addtocart(itemname, price);
        }

        private void btn_addjewelries1_Click(object sender, EventArgs e)
        {
            int price = 540000;
            string itemname = "Orbit Cargo Pants";
            addtocart(itemname, price);
        }

        private void btn_addjewelries2_Click(object sender, EventArgs e)
        {
            int price = 540000;
            string itemname = "Orbit Cargo Pants";
            addtocart(itemname, price);
        }

        private void btn_addjewelries3_Click(object sender, EventArgs e)
        {
            int price = 540000;
            string itemname = "Orbit Cargo Pants";
            addtocart(itemname, price);
        }

        private void tShirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_shirt.Visible = false;
            panel_tshirt.Visible = true;
            panel_pants.Visible = false;
            panel_longpants.Visible = false;
            panel_shoes.Visible = false;
            panel_jewelries.Visible = false;
            panel_others.Visible = false;
        }

        private void shirtToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_tshirt.Visible = false;
            panel_shirt.Visible = true;
            panel_pants.Visible = false;
            panel_longpants.Visible = false;
            panel_shoes.Visible = false;
            panel_jewelries.Visible = false;
            panel_others.Visible = false;
        }

        private void pantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_tshirt.Visible = false;
            panel_shirt.Visible = false;
            panel_pants.Visible = true;
            panel_longpants.Visible = false;
            panel_shoes.Visible = false;
            panel_jewelries.Visible = false;
            panel_others.Visible = false;
        }

        private void longPantsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_tshirt.Visible = false;
            panel_shirt.Visible = false;
            panel_pants.Visible = false;
            panel_longpants.Visible = true;
            panel_shoes.Visible = false;
            panel_jewelries.Visible = false;
            panel_others.Visible = false;
        }

        private void shoesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_tshirt.Visible = false;
            panel_shirt.Visible = false;
            panel_pants.Visible = false;
            panel_longpants.Visible = false;
            panel_shoes.Visible = true;
            panel_jewelries.Visible = false;
            panel_others.Visible = false;
        }

        private void jewelriesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            panel_tshirt.Visible = false;
            panel_shirt.Visible = false;
            panel_pants.Visible = false;
            panel_longpants.Visible = false;
            panel_shoes.Visible = false;
            panel_jewelries.Visible = true;
            panel_others.Visible = false;
        }

        private void tsm_others_Click(object sender, EventArgs e)
        {
            panel_tshirt.Visible = false;
            panel_shirt.Visible = false;
            panel_pants.Visible = false;
            panel_longpants.Visible = false;
            panel_shoes.Visible = false;
            panel_jewelries.Visible = false;
            panel_others.Visible = true;

            tb_itemname.Enabled = false;
            tb_itemprice.Enabled = false;
            btn_addothers.Enabled = false;

            tb_itemname.Clear();
            tb_itemprice.Clear();

            pb_others.Image = null;
        }

        private void btn_delete_Click(object sender, EventArgs e)
        {
            if (dgv_cart.SelectedCells.Count > 0)
            {
                DataRow dt_del = null;
                foreach (DataRow dt in dt.Rows)
                {
                    if (dt["Item"].ToString() == del)
                    {
                        dt_del = dt;
                        break;
                    }
                }
                if (dt_del != null)
                {
                    dt.Rows.Remove(dt_del);
                }
                dgv_cart.Refresh();
            }
            else
            {
                MessageBox.Show("Please select an item", "Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            total();
        }

        private void btn_upload_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "Image Files (*.jpg, *.jpeg, *.png, *.bmp)|*.jpg;*.jpeg;*.png;*.bmp";

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                pb_others.Image = Image.FromFile(openFileDialog.FileName);
                pb_others.SizeMode = PictureBoxSizeMode.Zoom;
                tb_itemname.Enabled = true;
                tb_itemprice.Enabled = true;
            }
        }

        private void btn_addothers_Click(object sender, EventArgs e)
        {
            string item = tb_itemname.Text;
            int price = Convert.ToInt32(tb_itemprice.Text);
            addtocart(item, price);
        }

        private void dgv_cart_CellMouseClick(object sender, DataGridViewCellMouseEventArgs e)
        {
            del = dgv_cart.CurrentRow.Cells[0].Value.ToString();
        }

        private void tb_itemprice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }

            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;
            }
        }
    }
}
