﻿namespace w08_appdev
{
    partial class form_uniqme
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(form_uniqme));
            this.menustrip = new System.Windows.Forms.MenuStrip();
            this.tsm_topwear = new System.Windows.Forms.ToolStripMenuItem();
            this.tShirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.shirtToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsm_bottomwear = new System.Windows.Forms.ToolStripMenuItem();
            this.pantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.longPantsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsm_accessories = new System.Windows.Forms.ToolStripMenuItem();
            this.shoesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.jewelriesToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tsm_others = new System.Windows.Forms.ToolStripMenuItem();
            this.panel_others = new System.Windows.Forms.Panel();
            this.tb_itemprice = new System.Windows.Forms.TextBox();
            this.tb_itemname = new System.Windows.Forms.TextBox();
            this.btn_addothers = new System.Windows.Forms.Button();
            this.btn_upload = new System.Windows.Forms.Button();
            this.lb_itemprice = new System.Windows.Forms.Label();
            this.lb_itemname = new System.Windows.Forms.Label();
            this.lb_upload = new System.Windows.Forms.Label();
            this.pb_others = new System.Windows.Forms.PictureBox();
            this.btn_delete = new System.Windows.Forms.Button();
            this.tb_total = new System.Windows.Forms.TextBox();
            this.tb_subtotal = new System.Windows.Forms.TextBox();
            this.lb_total = new System.Windows.Forms.Label();
            this.lb_subtotal = new System.Windows.Forms.Label();
            this.dgv_cart = new System.Windows.Forms.DataGridView();
            this.panel_shirt = new System.Windows.Forms.Panel();
            this.btn_addshirt3 = new System.Windows.Forms.Button();
            this.btn_addshirt2 = new System.Windows.Forms.Button();
            this.btn_addshirt1 = new System.Windows.Forms.Button();
            this.lb_priceshirt3 = new System.Windows.Forms.Label();
            this.lb_priceshirt2 = new System.Windows.Forms.Label();
            this.lb_priceshirt1 = new System.Windows.Forms.Label();
            this.lb_shirt3 = new System.Windows.Forms.Label();
            this.lb_shirt2 = new System.Windows.Forms.Label();
            this.lb_shirt1 = new System.Windows.Forms.Label();
            this.pbox_shirt3 = new System.Windows.Forms.PictureBox();
            this.pbox_shirt2 = new System.Windows.Forms.PictureBox();
            this.pbox_shirt1 = new System.Windows.Forms.PictureBox();
            this.panel_tshirt = new System.Windows.Forms.Panel();
            this.btn_addtshirt3 = new System.Windows.Forms.Button();
            this.btn_addtshirt2 = new System.Windows.Forms.Button();
            this.btn_addtshirt1 = new System.Windows.Forms.Button();
            this.lb_pricetshirt3 = new System.Windows.Forms.Label();
            this.lb_pricetshirt2 = new System.Windows.Forms.Label();
            this.lb_pricetshirt1 = new System.Windows.Forms.Label();
            this.lb_tshirt3 = new System.Windows.Forms.Label();
            this.lb_tshirt2 = new System.Windows.Forms.Label();
            this.lb_tshirt1 = new System.Windows.Forms.Label();
            this.pbox_tshirt3 = new System.Windows.Forms.PictureBox();
            this.pbox_tshirt2 = new System.Windows.Forms.PictureBox();
            this.pbox_tshirt1 = new System.Windows.Forms.PictureBox();
            this.panel_pants = new System.Windows.Forms.Panel();
            this.btn_addpants3 = new System.Windows.Forms.Button();
            this.btn_addpants2 = new System.Windows.Forms.Button();
            this.btn_addpants1 = new System.Windows.Forms.Button();
            this.lb_pricepants3 = new System.Windows.Forms.Label();
            this.lb_pricepants2 = new System.Windows.Forms.Label();
            this.lb_pricepants1 = new System.Windows.Forms.Label();
            this.lb_pants3 = new System.Windows.Forms.Label();
            this.lb_pants2 = new System.Windows.Forms.Label();
            this.lb_pants1 = new System.Windows.Forms.Label();
            this.pbox_pants3 = new System.Windows.Forms.PictureBox();
            this.pbox_pants2 = new System.Windows.Forms.PictureBox();
            this.pbox_pants1 = new System.Windows.Forms.PictureBox();
            this.panel_longpants = new System.Windows.Forms.Panel();
            this.btn_addlongpants3 = new System.Windows.Forms.Button();
            this.btn_addlongpants2 = new System.Windows.Forms.Button();
            this.btn_addlongpants1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.lb_longpants3 = new System.Windows.Forms.Label();
            this.lb_longpants2 = new System.Windows.Forms.Label();
            this.lb_longpants1 = new System.Windows.Forms.Label();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.panel_shoes = new System.Windows.Forms.Panel();
            this.btn_addshoes3 = new System.Windows.Forms.Button();
            this.btn_addshoes2 = new System.Windows.Forms.Button();
            this.btn_addshoes1 = new System.Windows.Forms.Button();
            this.lb_priceshoes3 = new System.Windows.Forms.Label();
            this.lb_priceshoes2 = new System.Windows.Forms.Label();
            this.lb_priceshoes1 = new System.Windows.Forms.Label();
            this.lb_shoes3 = new System.Windows.Forms.Label();
            this.lb_shoes2 = new System.Windows.Forms.Label();
            this.lb_shoes1 = new System.Windows.Forms.Label();
            this.pbox_shoes3 = new System.Windows.Forms.PictureBox();
            this.pbox_shoes2 = new System.Windows.Forms.PictureBox();
            this.pbox_shoes1 = new System.Windows.Forms.PictureBox();
            this.panel_jewelries = new System.Windows.Forms.Panel();
            this.btn_addjewelries3 = new System.Windows.Forms.Button();
            this.btn_addjewelries2 = new System.Windows.Forms.Button();
            this.btn_addjewelries1 = new System.Windows.Forms.Button();
            this.lb_pricejewelries3 = new System.Windows.Forms.Label();
            this.lb_pricejewelries2 = new System.Windows.Forms.Label();
            this.lb_pricejewelries1 = new System.Windows.Forms.Label();
            this.lb_jewelries3 = new System.Windows.Forms.Label();
            this.lb_jewelries2 = new System.Windows.Forms.Label();
            this.lb_jewelries1 = new System.Windows.Forms.Label();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.menustrip.SuspendLayout();
            this.panel_others.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_others)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_cart)).BeginInit();
            this.panel_shirt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_shirt3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_shirt2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_shirt1)).BeginInit();
            this.panel_tshirt.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_tshirt3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_tshirt2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_tshirt1)).BeginInit();
            this.panel_pants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_pants3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_pants2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_pants1)).BeginInit();
            this.panel_longpants.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            this.panel_shoes.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_shoes3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_shoes2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_shoes1)).BeginInit();
            this.panel_jewelries.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            this.SuspendLayout();
            // 
            // menustrip
            // 
            this.menustrip.GripMargin = new System.Windows.Forms.Padding(2, 2, 0, 2);
            this.menustrip.ImageScalingSize = new System.Drawing.Size(24, 24);
            this.menustrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tsm_topwear,
            this.tsm_bottomwear,
            this.tsm_accessories,
            this.tsm_others});
            this.menustrip.Location = new System.Drawing.Point(0, 0);
            this.menustrip.Name = "menustrip";
            this.menustrip.Padding = new System.Windows.Forms.Padding(4, 1, 0, 1);
            this.menustrip.Size = new System.Drawing.Size(1027, 31);
            this.menustrip.TabIndex = 0;
            this.menustrip.Text = "menuStrip1";
            // 
            // tsm_topwear
            // 
            this.tsm_topwear.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.tShirtToolStripMenuItem,
            this.shirtToolStripMenuItem});
            this.tsm_topwear.Name = "tsm_topwear";
            this.tsm_topwear.Size = new System.Drawing.Size(102, 29);
            this.tsm_topwear.Text = "Top Wear";
            // 
            // tShirtToolStripMenuItem
            // 
            this.tShirtToolStripMenuItem.Name = "tShirtToolStripMenuItem";
            this.tShirtToolStripMenuItem.Size = new System.Drawing.Size(166, 34);
            this.tShirtToolStripMenuItem.Text = "T-Shirt";
            this.tShirtToolStripMenuItem.Click += new System.EventHandler(this.tShirtToolStripMenuItem_Click);
            // 
            // shirtToolStripMenuItem
            // 
            this.shirtToolStripMenuItem.Name = "shirtToolStripMenuItem";
            this.shirtToolStripMenuItem.Size = new System.Drawing.Size(166, 34);
            this.shirtToolStripMenuItem.Text = "Shirt";
            this.shirtToolStripMenuItem.Click += new System.EventHandler(this.shirtToolStripMenuItem_Click);
            // 
            // tsm_bottomwear
            // 
            this.tsm_bottomwear.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.pantsToolStripMenuItem,
            this.longPantsToolStripMenuItem});
            this.tsm_bottomwear.Name = "tsm_bottomwear";
            this.tsm_bottomwear.Size = new System.Drawing.Size(133, 29);
            this.tsm_bottomwear.Text = "Bottom Wear";
            // 
            // pantsToolStripMenuItem
            // 
            this.pantsToolStripMenuItem.Name = "pantsToolStripMenuItem";
            this.pantsToolStripMenuItem.Size = new System.Drawing.Size(201, 34);
            this.pantsToolStripMenuItem.Text = "Pants";
            this.pantsToolStripMenuItem.Click += new System.EventHandler(this.pantsToolStripMenuItem_Click);
            // 
            // longPantsToolStripMenuItem
            // 
            this.longPantsToolStripMenuItem.Name = "longPantsToolStripMenuItem";
            this.longPantsToolStripMenuItem.Size = new System.Drawing.Size(201, 34);
            this.longPantsToolStripMenuItem.Text = "Long Pants";
            this.longPantsToolStripMenuItem.Click += new System.EventHandler(this.longPantsToolStripMenuItem_Click);
            // 
            // tsm_accessories
            // 
            this.tsm_accessories.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.shoesToolStripMenuItem,
            this.jewelriesToolStripMenuItem});
            this.tsm_accessories.Name = "tsm_accessories";
            this.tsm_accessories.Size = new System.Drawing.Size(119, 29);
            this.tsm_accessories.Text = "Accessories";
            // 
            // shoesToolStripMenuItem
            // 
            this.shoesToolStripMenuItem.Name = "shoesToolStripMenuItem";
            this.shoesToolStripMenuItem.Size = new System.Drawing.Size(182, 34);
            this.shoesToolStripMenuItem.Text = "Shoes";
            this.shoesToolStripMenuItem.Click += new System.EventHandler(this.shoesToolStripMenuItem_Click);
            // 
            // jewelriesToolStripMenuItem
            // 
            this.jewelriesToolStripMenuItem.Name = "jewelriesToolStripMenuItem";
            this.jewelriesToolStripMenuItem.Size = new System.Drawing.Size(182, 34);
            this.jewelriesToolStripMenuItem.Text = "Jewelries";
            this.jewelriesToolStripMenuItem.Click += new System.EventHandler(this.jewelriesToolStripMenuItem_Click);
            // 
            // tsm_others
            // 
            this.tsm_others.Name = "tsm_others";
            this.tsm_others.Size = new System.Drawing.Size(81, 29);
            this.tsm_others.Text = "Others";
            this.tsm_others.Click += new System.EventHandler(this.tsm_others_Click);
            // 
            // panel_others
            // 
            this.panel_others.Controls.Add(this.tb_itemprice);
            this.panel_others.Controls.Add(this.tb_itemname);
            this.panel_others.Controls.Add(this.btn_addothers);
            this.panel_others.Controls.Add(this.btn_upload);
            this.panel_others.Controls.Add(this.lb_itemprice);
            this.panel_others.Controls.Add(this.lb_itemname);
            this.panel_others.Controls.Add(this.lb_upload);
            this.panel_others.Controls.Add(this.pb_others);
            this.panel_others.Location = new System.Drawing.Point(42, 63);
            this.panel_others.Name = "panel_others";
            this.panel_others.Size = new System.Drawing.Size(388, 285);
            this.panel_others.TabIndex = 18;
            this.panel_others.Visible = false;
            // 
            // tb_itemprice
            // 
            this.tb_itemprice.Enabled = false;
            this.tb_itemprice.Location = new System.Drawing.Point(206, 164);
            this.tb_itemprice.Name = "tb_itemprice";
            this.tb_itemprice.Size = new System.Drawing.Size(130, 20);
            this.tb_itemprice.TabIndex = 13;
            this.tb_itemprice.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tb_itemprice_KeyPress);
            // 
            // tb_itemname
            // 
            this.tb_itemname.Enabled = false;
            this.tb_itemname.Location = new System.Drawing.Point(206, 106);
            this.tb_itemname.Name = "tb_itemname";
            this.tb_itemname.Size = new System.Drawing.Size(130, 20);
            this.tb_itemname.TabIndex = 12;
            // 
            // btn_addothers
            // 
            this.btn_addothers.Enabled = false;
            this.btn_addothers.Location = new System.Drawing.Point(206, 208);
            this.btn_addothers.Name = "btn_addothers";
            this.btn_addothers.Size = new System.Drawing.Size(110, 36);
            this.btn_addothers.TabIndex = 11;
            this.btn_addothers.Text = "Add to Cart";
            this.btn_addothers.UseVisualStyleBackColor = true;
            this.btn_addothers.Click += new System.EventHandler(this.btn_addothers_Click);
            // 
            // btn_upload
            // 
            this.btn_upload.Location = new System.Drawing.Point(197, 23);
            this.btn_upload.Name = "btn_upload";
            this.btn_upload.Size = new System.Drawing.Size(74, 33);
            this.btn_upload.TabIndex = 10;
            this.btn_upload.Text = "Upload";
            this.btn_upload.UseVisualStyleBackColor = true;
            this.btn_upload.Click += new System.EventHandler(this.btn_upload_Click);
            // 
            // lb_itemprice
            // 
            this.lb_itemprice.AutoSize = true;
            this.lb_itemprice.Location = new System.Drawing.Point(202, 141);
            this.lb_itemprice.Name = "lb_itemprice";
            this.lb_itemprice.Size = new System.Drawing.Size(57, 13);
            this.lb_itemprice.TabIndex = 6;
            this.lb_itemprice.Text = "Item Price:";
            // 
            // lb_itemname
            // 
            this.lb_itemname.AutoSize = true;
            this.lb_itemname.Location = new System.Drawing.Point(202, 83);
            this.lb_itemname.Name = "lb_itemname";
            this.lb_itemname.Size = new System.Drawing.Size(61, 13);
            this.lb_itemname.TabIndex = 4;
            this.lb_itemname.Text = "Item Name:";
            // 
            // lb_upload
            // 
            this.lb_upload.AutoSize = true;
            this.lb_upload.Location = new System.Drawing.Point(37, 33);
            this.lb_upload.Name = "lb_upload";
            this.lb_upload.Size = new System.Drawing.Size(73, 13);
            this.lb_upload.TabIndex = 3;
            this.lb_upload.Text = "Upload Image";
            // 
            // pb_others
            // 
            this.pb_others.BackColor = System.Drawing.SystemColors.ControlLight;
            this.pb_others.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pb_others.Location = new System.Drawing.Point(40, 62);
            this.pb_others.Name = "pb_others";
            this.pb_others.Size = new System.Drawing.Size(134, 175);
            this.pb_others.TabIndex = 0;
            this.pb_others.TabStop = false;
            // 
            // btn_delete
            // 
            this.btn_delete.Location = new System.Drawing.Point(879, 409);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(103, 35);
            this.btn_delete.TabIndex = 24;
            this.btn_delete.Text = "Delete";
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.btn_delete_Click);
            // 
            // tb_total
            // 
            this.tb_total.Enabled = false;
            this.tb_total.Location = new System.Drawing.Point(639, 466);
            this.tb_total.Name = "tb_total";
            this.tb_total.Size = new System.Drawing.Size(162, 20);
            this.tb_total.TabIndex = 23;
            // 
            // tb_subtotal
            // 
            this.tb_subtotal.Enabled = false;
            this.tb_subtotal.Location = new System.Drawing.Point(639, 423);
            this.tb_subtotal.Name = "tb_subtotal";
            this.tb_subtotal.Size = new System.Drawing.Size(162, 20);
            this.tb_subtotal.TabIndex = 22;
            // 
            // lb_total
            // 
            this.lb_total.AutoSize = true;
            this.lb_total.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_total.Location = new System.Drawing.Point(492, 457);
            this.lb_total.Name = "lb_total";
            this.lb_total.Size = new System.Drawing.Size(87, 29);
            this.lb_total.TabIndex = 21;
            this.lb_total.Text = "Total :";
            // 
            // lb_subtotal
            // 
            this.lb_subtotal.AutoSize = true;
            this.lb_subtotal.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_subtotal.Location = new System.Drawing.Point(492, 419);
            this.lb_subtotal.Name = "lb_subtotal";
            this.lb_subtotal.Size = new System.Drawing.Size(142, 29);
            this.lb_subtotal.TabIndex = 20;
            this.lb_subtotal.Text = "Sub-Total :";
            // 
            // dgv_cart
            // 
            this.dgv_cart.AllowUserToAddRows = false;
            this.dgv_cart.AllowUserToDeleteRows = false;
            this.dgv_cart.AllowUserToResizeColumns = false;
            this.dgv_cart.AllowUserToResizeRows = false;
            this.dgv_cart.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_cart.Location = new System.Drawing.Point(497, 63);
            this.dgv_cart.Name = "dgv_cart";
            this.dgv_cart.ReadOnly = true;
            this.dgv_cart.RowHeadersVisible = false;
            this.dgv_cart.RowHeadersWidth = 62;
            this.dgv_cart.RowTemplate.Height = 28;
            this.dgv_cart.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgv_cart.Size = new System.Drawing.Size(485, 333);
            this.dgv_cart.TabIndex = 19;
            this.dgv_cart.CellMouseClick += new System.Windows.Forms.DataGridViewCellMouseEventHandler(this.dgv_cart_CellMouseClick);
            // 
            // panel_shirt
            // 
            this.panel_shirt.Controls.Add(this.btn_addshirt3);
            this.panel_shirt.Controls.Add(this.btn_addshirt2);
            this.panel_shirt.Controls.Add(this.panel_longpants);
            this.panel_shirt.Controls.Add(this.btn_addshirt1);
            this.panel_shirt.Controls.Add(this.lb_priceshirt3);
            this.panel_shirt.Controls.Add(this.lb_priceshirt2);
            this.panel_shirt.Controls.Add(this.lb_priceshirt1);
            this.panel_shirt.Controls.Add(this.lb_shirt3);
            this.panel_shirt.Controls.Add(this.lb_shirt2);
            this.panel_shirt.Controls.Add(this.lb_shirt1);
            this.panel_shirt.Controls.Add(this.pbox_shirt3);
            this.panel_shirt.Controls.Add(this.pbox_shirt2);
            this.panel_shirt.Controls.Add(this.pbox_shirt1);
            this.panel_shirt.Location = new System.Drawing.Point(0, 0);
            this.panel_shirt.Margin = new System.Windows.Forms.Padding(2);
            this.panel_shirt.Name = "panel_shirt";
            this.panel_shirt.Size = new System.Drawing.Size(386, 194);
            this.panel_shirt.TabIndex = 25;
            // 
            // btn_addshirt3
            // 
            this.btn_addshirt3.Location = new System.Drawing.Point(272, 166);
            this.btn_addshirt3.Margin = new System.Windows.Forms.Padding(2);
            this.btn_addshirt3.Name = "btn_addshirt3";
            this.btn_addshirt3.Size = new System.Drawing.Size(71, 20);
            this.btn_addshirt3.TabIndex = 17;
            this.btn_addshirt3.Text = "Add to Cart";
            this.btn_addshirt3.UseVisualStyleBackColor = true;
            this.btn_addshirt3.Click += new System.EventHandler(this.btn_addshirt3_Click);
            // 
            // btn_addshirt2
            // 
            this.btn_addshirt2.Location = new System.Drawing.Point(139, 166);
            this.btn_addshirt2.Margin = new System.Windows.Forms.Padding(2);
            this.btn_addshirt2.Name = "btn_addshirt2";
            this.btn_addshirt2.Size = new System.Drawing.Size(71, 20);
            this.btn_addshirt2.TabIndex = 16;
            this.btn_addshirt2.Text = "Add to Cart";
            this.btn_addshirt2.UseVisualStyleBackColor = true;
            this.btn_addshirt2.Click += new System.EventHandler(this.btn_addshirt2_Click);
            // 
            // btn_addshirt1
            // 
            this.btn_addshirt1.Location = new System.Drawing.Point(6, 166);
            this.btn_addshirt1.Margin = new System.Windows.Forms.Padding(2);
            this.btn_addshirt1.Name = "btn_addshirt1";
            this.btn_addshirt1.Size = new System.Drawing.Size(71, 20);
            this.btn_addshirt1.TabIndex = 15;
            this.btn_addshirt1.Text = "Add to Cart";
            this.btn_addshirt1.UseVisualStyleBackColor = true;
            this.btn_addshirt1.Click += new System.EventHandler(this.btn_addshirt1_Click);
            // 
            // lb_priceshirt3
            // 
            this.lb_priceshirt3.AutoSize = true;
            this.lb_priceshirt3.Location = new System.Drawing.Point(270, 140);
            this.lb_priceshirt3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_priceshirt3.Name = "lb_priceshirt3";
            this.lb_priceshirt3.Size = new System.Drawing.Size(81, 13);
            this.lb_priceshirt3.TabIndex = 14;
            this.lb_priceshirt3.Text = "Rp. 500.000,00";
            // 
            // lb_priceshirt2
            // 
            this.lb_priceshirt2.AutoSize = true;
            this.lb_priceshirt2.Location = new System.Drawing.Point(136, 140);
            this.lb_priceshirt2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_priceshirt2.Name = "lb_priceshirt2";
            this.lb_priceshirt2.Size = new System.Drawing.Size(81, 13);
            this.lb_priceshirt2.TabIndex = 13;
            this.lb_priceshirt2.Text = "Rp. 480.000,00";
            // 
            // lb_priceshirt1
            // 
            this.lb_priceshirt1.AutoSize = true;
            this.lb_priceshirt1.Location = new System.Drawing.Point(4, 140);
            this.lb_priceshirt1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_priceshirt1.Name = "lb_priceshirt1";
            this.lb_priceshirt1.Size = new System.Drawing.Size(81, 13);
            this.lb_priceshirt1.TabIndex = 12;
            this.lb_priceshirt1.Text = "Rp. 430.000,00";
            // 
            // lb_shirt3
            // 
            this.lb_shirt3.AutoSize = true;
            this.lb_shirt3.Location = new System.Drawing.Point(270, 120);
            this.lb_shirt3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_shirt3.Name = "lb_shirt3";
            this.lb_shirt3.Size = new System.Drawing.Size(105, 13);
            this.lb_shirt3.TabIndex = 11;
            this.lb_shirt3.Text = "Fit Long Sleeve Shirt";
            // 
            // lb_shirt2
            // 
            this.lb_shirt2.AutoSize = true;
            this.lb_shirt2.Location = new System.Drawing.Point(136, 120);
            this.lb_shirt2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_shirt2.Name = "lb_shirt2";
            this.lb_shirt2.Size = new System.Drawing.Size(119, 13);
            this.lb_shirt2.TabIndex = 10;
            this.lb_shirt2.Text = "Printed Embroidery Shirt";
            // 
            // lb_shirt1
            // 
            this.lb_shirt1.AutoSize = true;
            this.lb_shirt1.Location = new System.Drawing.Point(4, 120);
            this.lb_shirt1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_shirt1.Name = "lb_shirt1";
            this.lb_shirt1.Size = new System.Drawing.Size(98, 13);
            this.lb_shirt1.TabIndex = 9;
            this.lb_shirt1.Text = "Classic Formal Shirt";
            // 
            // pbox_shirt3
            // 
            this.pbox_shirt3.Image = ((System.Drawing.Image)(resources.GetObject("pbox_shirt3.Image")));
            this.pbox_shirt3.Location = new System.Drawing.Point(272, 7);
            this.pbox_shirt3.Margin = new System.Windows.Forms.Padding(2);
            this.pbox_shirt3.Name = "pbox_shirt3";
            this.pbox_shirt3.Size = new System.Drawing.Size(102, 106);
            this.pbox_shirt3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox_shirt3.TabIndex = 8;
            this.pbox_shirt3.TabStop = false;
            // 
            // pbox_shirt2
            // 
            this.pbox_shirt2.Image = ((System.Drawing.Image)(resources.GetObject("pbox_shirt2.Image")));
            this.pbox_shirt2.Location = new System.Drawing.Point(139, 7);
            this.pbox_shirt2.Margin = new System.Windows.Forms.Padding(2);
            this.pbox_shirt2.Name = "pbox_shirt2";
            this.pbox_shirt2.Size = new System.Drawing.Size(102, 106);
            this.pbox_shirt2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox_shirt2.TabIndex = 7;
            this.pbox_shirt2.TabStop = false;
            // 
            // pbox_shirt1
            // 
            this.pbox_shirt1.Image = ((System.Drawing.Image)(resources.GetObject("pbox_shirt1.Image")));
            this.pbox_shirt1.Location = new System.Drawing.Point(6, 7);
            this.pbox_shirt1.Margin = new System.Windows.Forms.Padding(2);
            this.pbox_shirt1.Name = "pbox_shirt1";
            this.pbox_shirt1.Size = new System.Drawing.Size(102, 106);
            this.pbox_shirt1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox_shirt1.TabIndex = 6;
            this.pbox_shirt1.TabStop = false;
            // 
            // panel_tshirt
            // 
            this.panel_tshirt.Controls.Add(this.btn_addtshirt3);
            this.panel_tshirt.Controls.Add(this.btn_addtshirt2);
            this.panel_tshirt.Controls.Add(this.btn_addtshirt1);
            this.panel_tshirt.Controls.Add(this.lb_pricetshirt3);
            this.panel_tshirt.Controls.Add(this.lb_pricetshirt2);
            this.panel_tshirt.Controls.Add(this.panel_shirt);
            this.panel_tshirt.Controls.Add(this.lb_pricetshirt1);
            this.panel_tshirt.Controls.Add(this.lb_tshirt3);
            this.panel_tshirt.Controls.Add(this.lb_tshirt2);
            this.panel_tshirt.Controls.Add(this.lb_tshirt1);
            this.panel_tshirt.Controls.Add(this.pbox_tshirt3);
            this.panel_tshirt.Controls.Add(this.pbox_tshirt2);
            this.panel_tshirt.Controls.Add(this.pbox_tshirt1);
            this.panel_tshirt.Location = new System.Drawing.Point(44, 63);
            this.panel_tshirt.Margin = new System.Windows.Forms.Padding(2);
            this.panel_tshirt.Name = "panel_tshirt";
            this.panel_tshirt.Size = new System.Drawing.Size(386, 194);
            this.panel_tshirt.TabIndex = 26;
            // 
            // btn_addtshirt3
            // 
            this.btn_addtshirt3.Location = new System.Drawing.Point(272, 166);
            this.btn_addtshirt3.Margin = new System.Windows.Forms.Padding(2);
            this.btn_addtshirt3.Name = "btn_addtshirt3";
            this.btn_addtshirt3.Size = new System.Drawing.Size(71, 20);
            this.btn_addtshirt3.TabIndex = 17;
            this.btn_addtshirt3.Text = "Add to Cart";
            this.btn_addtshirt3.UseVisualStyleBackColor = true;
            this.btn_addtshirt3.Click += new System.EventHandler(this.btn_addtshirt3_Click);
            // 
            // btn_addtshirt2
            // 
            this.btn_addtshirt2.Location = new System.Drawing.Point(139, 166);
            this.btn_addtshirt2.Margin = new System.Windows.Forms.Padding(2);
            this.btn_addtshirt2.Name = "btn_addtshirt2";
            this.btn_addtshirt2.Size = new System.Drawing.Size(71, 20);
            this.btn_addtshirt2.TabIndex = 16;
            this.btn_addtshirt2.Text = "Add to Cart";
            this.btn_addtshirt2.UseVisualStyleBackColor = true;
            this.btn_addtshirt2.Click += new System.EventHandler(this.btn_addtshirt2_Click);
            // 
            // btn_addtshirt1
            // 
            this.btn_addtshirt1.Location = new System.Drawing.Point(6, 166);
            this.btn_addtshirt1.Margin = new System.Windows.Forms.Padding(2);
            this.btn_addtshirt1.Name = "btn_addtshirt1";
            this.btn_addtshirt1.Size = new System.Drawing.Size(71, 20);
            this.btn_addtshirt1.TabIndex = 15;
            this.btn_addtshirt1.Text = "Add to Cart";
            this.btn_addtshirt1.UseVisualStyleBackColor = true;
            this.btn_addtshirt1.Click += new System.EventHandler(this.btn_addtshirt1_Click);
            // 
            // lb_pricetshirt3
            // 
            this.lb_pricetshirt3.AutoSize = true;
            this.lb_pricetshirt3.Location = new System.Drawing.Point(270, 140);
            this.lb_pricetshirt3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_pricetshirt3.Name = "lb_pricetshirt3";
            this.lb_pricetshirt3.Size = new System.Drawing.Size(81, 13);
            this.lb_pricetshirt3.TabIndex = 14;
            this.lb_pricetshirt3.Text = "Rp. 380.000,00";
            // 
            // lb_pricetshirt2
            // 
            this.lb_pricetshirt2.AutoSize = true;
            this.lb_pricetshirt2.Location = new System.Drawing.Point(136, 140);
            this.lb_pricetshirt2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_pricetshirt2.Name = "lb_pricetshirt2";
            this.lb_pricetshirt2.Size = new System.Drawing.Size(81, 13);
            this.lb_pricetshirt2.TabIndex = 13;
            this.lb_pricetshirt2.Text = "Rp. 350.000,00";
            // 
            // lb_pricetshirt1
            // 
            this.lb_pricetshirt1.AutoSize = true;
            this.lb_pricetshirt1.Location = new System.Drawing.Point(4, 140);
            this.lb_pricetshirt1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_pricetshirt1.Name = "lb_pricetshirt1";
            this.lb_pricetshirt1.Size = new System.Drawing.Size(81, 13);
            this.lb_pricetshirt1.TabIndex = 12;
            this.lb_pricetshirt1.Text = "Rp. 200.000,00";
            // 
            // lb_tshirt3
            // 
            this.lb_tshirt3.AutoSize = true;
            this.lb_tshirt3.Location = new System.Drawing.Point(270, 120);
            this.lb_tshirt3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_tshirt3.Name = "lb_tshirt3";
            this.lb_tshirt3.Size = new System.Drawing.Size(90, 13);
            this.lb_tshirt3.TabIndex = 11;
            this.lb_tshirt3.Text = "Boxy-Style T-Shirt";
            // 
            // lb_tshirt2
            // 
            this.lb_tshirt2.AutoSize = true;
            this.lb_tshirt2.Location = new System.Drawing.Point(136, 120);
            this.lb_tshirt2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_tshirt2.Name = "lb_tshirt2";
            this.lb_tshirt2.Size = new System.Drawing.Size(124, 13);
            this.lb_tshirt2.TabIndex = 10;
            this.lb_tshirt2.Text = "Oversized Printed T-Shirt";
            // 
            // lb_tshirt1
            // 
            this.lb_tshirt1.AutoSize = true;
            this.lb_tshirt1.Location = new System.Drawing.Point(4, 120);
            this.lb_tshirt1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_tshirt1.Name = "lb_tshirt1";
            this.lb_tshirt1.Size = new System.Drawing.Size(120, 13);
            this.lb_tshirt1.TabIndex = 9;
            this.lb_tshirt1.Text = "Loose Fit Printed T-Shirt";
            // 
            // pbox_tshirt3
            // 
            this.pbox_tshirt3.Image = ((System.Drawing.Image)(resources.GetObject("pbox_tshirt3.Image")));
            this.pbox_tshirt3.Location = new System.Drawing.Point(272, 7);
            this.pbox_tshirt3.Margin = new System.Windows.Forms.Padding(2);
            this.pbox_tshirt3.Name = "pbox_tshirt3";
            this.pbox_tshirt3.Size = new System.Drawing.Size(102, 106);
            this.pbox_tshirt3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox_tshirt3.TabIndex = 8;
            this.pbox_tshirt3.TabStop = false;
            // 
            // pbox_tshirt2
            // 
            this.pbox_tshirt2.Image = ((System.Drawing.Image)(resources.GetObject("pbox_tshirt2.Image")));
            this.pbox_tshirt2.Location = new System.Drawing.Point(139, 7);
            this.pbox_tshirt2.Margin = new System.Windows.Forms.Padding(2);
            this.pbox_tshirt2.Name = "pbox_tshirt2";
            this.pbox_tshirt2.Size = new System.Drawing.Size(102, 106);
            this.pbox_tshirt2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox_tshirt2.TabIndex = 7;
            this.pbox_tshirt2.TabStop = false;
            // 
            // pbox_tshirt1
            // 
            this.pbox_tshirt1.Image = ((System.Drawing.Image)(resources.GetObject("pbox_tshirt1.Image")));
            this.pbox_tshirt1.Location = new System.Drawing.Point(6, 7);
            this.pbox_tshirt1.Margin = new System.Windows.Forms.Padding(2);
            this.pbox_tshirt1.Name = "pbox_tshirt1";
            this.pbox_tshirt1.Size = new System.Drawing.Size(102, 106);
            this.pbox_tshirt1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox_tshirt1.TabIndex = 6;
            this.pbox_tshirt1.TabStop = false;
            // 
            // panel_pants
            // 
            this.panel_pants.Controls.Add(this.btn_addpants3);
            this.panel_pants.Controls.Add(this.panel_shoes);
            this.panel_pants.Controls.Add(this.btn_addpants2);
            this.panel_pants.Controls.Add(this.btn_addpants1);
            this.panel_pants.Controls.Add(this.lb_pricepants3);
            this.panel_pants.Controls.Add(this.lb_pricepants2);
            this.panel_pants.Controls.Add(this.lb_pricepants1);
            this.panel_pants.Controls.Add(this.lb_pants3);
            this.panel_pants.Controls.Add(this.lb_pants2);
            this.panel_pants.Controls.Add(this.lb_pants1);
            this.panel_pants.Controls.Add(this.pbox_pants3);
            this.panel_pants.Controls.Add(this.pbox_pants2);
            this.panel_pants.Controls.Add(this.pbox_pants1);
            this.panel_pants.Location = new System.Drawing.Point(42, 63);
            this.panel_pants.Margin = new System.Windows.Forms.Padding(2);
            this.panel_pants.Name = "panel_pants";
            this.panel_pants.Size = new System.Drawing.Size(386, 194);
            this.panel_pants.TabIndex = 27;
            // 
            // btn_addpants3
            // 
            this.btn_addpants3.Location = new System.Drawing.Point(272, 166);
            this.btn_addpants3.Margin = new System.Windows.Forms.Padding(2);
            this.btn_addpants3.Name = "btn_addpants3";
            this.btn_addpants3.Size = new System.Drawing.Size(71, 20);
            this.btn_addpants3.TabIndex = 17;
            this.btn_addpants3.Text = "Add to Cart";
            this.btn_addpants3.UseVisualStyleBackColor = true;
            this.btn_addpants3.Click += new System.EventHandler(this.btn_addpants3_Click);
            // 
            // btn_addpants2
            // 
            this.btn_addpants2.Location = new System.Drawing.Point(139, 166);
            this.btn_addpants2.Margin = new System.Windows.Forms.Padding(2);
            this.btn_addpants2.Name = "btn_addpants2";
            this.btn_addpants2.Size = new System.Drawing.Size(71, 20);
            this.btn_addpants2.TabIndex = 16;
            this.btn_addpants2.Text = "Add to Cart";
            this.btn_addpants2.UseVisualStyleBackColor = true;
            this.btn_addpants2.Click += new System.EventHandler(this.btn_addpants2_Click);
            // 
            // btn_addpants1
            // 
            this.btn_addpants1.Location = new System.Drawing.Point(6, 166);
            this.btn_addpants1.Margin = new System.Windows.Forms.Padding(2);
            this.btn_addpants1.Name = "btn_addpants1";
            this.btn_addpants1.Size = new System.Drawing.Size(71, 20);
            this.btn_addpants1.TabIndex = 15;
            this.btn_addpants1.Text = "Add to Cart";
            this.btn_addpants1.UseVisualStyleBackColor = true;
            this.btn_addpants1.Click += new System.EventHandler(this.btn_addpants1_Click);
            // 
            // lb_pricepants3
            // 
            this.lb_pricepants3.AutoSize = true;
            this.lb_pricepants3.Location = new System.Drawing.Point(270, 140);
            this.lb_pricepants3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_pricepants3.Name = "lb_pricepants3";
            this.lb_pricepants3.Size = new System.Drawing.Size(81, 13);
            this.lb_pricepants3.TabIndex = 14;
            this.lb_pricepants3.Text = "Rp. 500.000,00";
            // 
            // lb_pricepants2
            // 
            this.lb_pricepants2.AutoSize = true;
            this.lb_pricepants2.Location = new System.Drawing.Point(136, 140);
            this.lb_pricepants2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_pricepants2.Name = "lb_pricepants2";
            this.lb_pricepants2.Size = new System.Drawing.Size(81, 13);
            this.lb_pricepants2.TabIndex = 13;
            this.lb_pricepants2.Text = "Rp. 430.000,00";
            // 
            // lb_pricepants1
            // 
            this.lb_pricepants1.AutoSize = true;
            this.lb_pricepants1.Location = new System.Drawing.Point(4, 140);
            this.lb_pricepants1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_pricepants1.Name = "lb_pricepants1";
            this.lb_pricepants1.Size = new System.Drawing.Size(81, 13);
            this.lb_pricepants1.TabIndex = 12;
            this.lb_pricepants1.Text = "Rp. 450.000,00";
            // 
            // lb_pants3
            // 
            this.lb_pants3.AutoSize = true;
            this.lb_pants3.Location = new System.Drawing.Point(270, 120);
            this.lb_pants3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_pants3.Name = "lb_pants3";
            this.lb_pants3.Size = new System.Drawing.Size(94, 13);
            this.lb_pants3.TabIndex = 11;
            this.lb_pants3.Text = "Ultra Comfy Shorts";
            // 
            // lb_pants2
            // 
            this.lb_pants2.AutoSize = true;
            this.lb_pants2.Location = new System.Drawing.Point(136, 120);
            this.lb_pants2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_pants2.Name = "lb_pants2";
            this.lb_pants2.Size = new System.Drawing.Size(94, 13);
            this.lb_pants2.TabIndex = 10;
            this.lb_pants2.Text = "Cane Linen Shorts";
            // 
            // lb_pants1
            // 
            this.lb_pants1.AutoSize = true;
            this.lb_pants1.Location = new System.Drawing.Point(4, 120);
            this.lb_pants1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_pants1.Name = "lb_pants1";
            this.lb_pants1.Size = new System.Drawing.Size(85, 13);
            this.lb_pants1.TabIndex = 9;
            this.lb_pants1.Text = "Lois Short Jeans";
            // 
            // pbox_pants3
            // 
            this.pbox_pants3.Image = ((System.Drawing.Image)(resources.GetObject("pbox_pants3.Image")));
            this.pbox_pants3.Location = new System.Drawing.Point(272, 7);
            this.pbox_pants3.Margin = new System.Windows.Forms.Padding(2);
            this.pbox_pants3.Name = "pbox_pants3";
            this.pbox_pants3.Size = new System.Drawing.Size(102, 106);
            this.pbox_pants3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox_pants3.TabIndex = 8;
            this.pbox_pants3.TabStop = false;
            // 
            // pbox_pants2
            // 
            this.pbox_pants2.Image = ((System.Drawing.Image)(resources.GetObject("pbox_pants2.Image")));
            this.pbox_pants2.Location = new System.Drawing.Point(139, 7);
            this.pbox_pants2.Margin = new System.Windows.Forms.Padding(2);
            this.pbox_pants2.Name = "pbox_pants2";
            this.pbox_pants2.Size = new System.Drawing.Size(102, 106);
            this.pbox_pants2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox_pants2.TabIndex = 7;
            this.pbox_pants2.TabStop = false;
            // 
            // pbox_pants1
            // 
            this.pbox_pants1.Image = ((System.Drawing.Image)(resources.GetObject("pbox_pants1.Image")));
            this.pbox_pants1.Location = new System.Drawing.Point(6, 7);
            this.pbox_pants1.Margin = new System.Windows.Forms.Padding(2);
            this.pbox_pants1.Name = "pbox_pants1";
            this.pbox_pants1.Size = new System.Drawing.Size(102, 106);
            this.pbox_pants1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox_pants1.TabIndex = 6;
            this.pbox_pants1.TabStop = false;
            // 
            // panel_longpants
            // 
            this.panel_longpants.Controls.Add(this.btn_addlongpants3);
            this.panel_longpants.Controls.Add(this.btn_addlongpants2);
            this.panel_longpants.Controls.Add(this.btn_addlongpants1);
            this.panel_longpants.Controls.Add(this.label1);
            this.panel_longpants.Controls.Add(this.label2);
            this.panel_longpants.Controls.Add(this.label3);
            this.panel_longpants.Controls.Add(this.lb_longpants3);
            this.panel_longpants.Controls.Add(this.lb_longpants2);
            this.panel_longpants.Controls.Add(this.lb_longpants1);
            this.panel_longpants.Controls.Add(this.pictureBox1);
            this.panel_longpants.Controls.Add(this.pictureBox2);
            this.panel_longpants.Controls.Add(this.pictureBox3);
            this.panel_longpants.Location = new System.Drawing.Point(0, 0);
            this.panel_longpants.Margin = new System.Windows.Forms.Padding(2);
            this.panel_longpants.Name = "panel_longpants";
            this.panel_longpants.Size = new System.Drawing.Size(386, 194);
            this.panel_longpants.TabIndex = 28;
            // 
            // btn_addlongpants3
            // 
            this.btn_addlongpants3.Location = new System.Drawing.Point(272, 166);
            this.btn_addlongpants3.Margin = new System.Windows.Forms.Padding(2);
            this.btn_addlongpants3.Name = "btn_addlongpants3";
            this.btn_addlongpants3.Size = new System.Drawing.Size(71, 20);
            this.btn_addlongpants3.TabIndex = 17;
            this.btn_addlongpants3.Text = "Add to Cart";
            this.btn_addlongpants3.UseVisualStyleBackColor = true;
            this.btn_addlongpants3.Click += new System.EventHandler(this.btn_addlongpants3_Click);
            // 
            // btn_addlongpants2
            // 
            this.btn_addlongpants2.Location = new System.Drawing.Point(139, 166);
            this.btn_addlongpants2.Margin = new System.Windows.Forms.Padding(2);
            this.btn_addlongpants2.Name = "btn_addlongpants2";
            this.btn_addlongpants2.Size = new System.Drawing.Size(71, 20);
            this.btn_addlongpants2.TabIndex = 16;
            this.btn_addlongpants2.Text = "Add to Cart";
            this.btn_addlongpants2.UseVisualStyleBackColor = true;
            this.btn_addlongpants2.Click += new System.EventHandler(this.btn_addlongpants2_Click);
            // 
            // btn_addlongpants1
            // 
            this.btn_addlongpants1.Location = new System.Drawing.Point(6, 166);
            this.btn_addlongpants1.Margin = new System.Windows.Forms.Padding(2);
            this.btn_addlongpants1.Name = "btn_addlongpants1";
            this.btn_addlongpants1.Size = new System.Drawing.Size(71, 20);
            this.btn_addlongpants1.TabIndex = 15;
            this.btn_addlongpants1.Text = "Add to Cart";
            this.btn_addlongpants1.UseVisualStyleBackColor = true;
            this.btn_addlongpants1.Click += new System.EventHandler(this.btn_addlongpants1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(270, 140);
            this.label1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(81, 13);
            this.label1.TabIndex = 14;
            this.label1.Text = "Rp. 540.000,00";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(136, 140);
            this.label2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(81, 13);
            this.label2.TabIndex = 13;
            this.label2.Text = "Rp. 600.000,00";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(4, 140);
            this.label3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(90, 13);
            this.label3.TabIndex = 12;
            this.label3.Text = "Rp. 1.260.000,00";
            // 
            // lb_longpants3
            // 
            this.lb_longpants3.AutoSize = true;
            this.lb_longpants3.Location = new System.Drawing.Point(270, 120);
            this.lb_longpants3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_longpants3.Name = "lb_longpants3";
            this.lb_longpants3.Size = new System.Drawing.Size(90, 13);
            this.lb_longpants3.TabIndex = 11;
            this.lb_longpants3.Text = "Orbit Cargo Pants";
            // 
            // lb_longpants2
            // 
            this.lb_longpants2.AutoSize = true;
            this.lb_longpants2.Location = new System.Drawing.Point(136, 120);
            this.lb_longpants2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_longpants2.Name = "lb_longpants2";
            this.lb_longpants2.Size = new System.Drawing.Size(106, 13);
            this.lb_longpants2.TabIndex = 10;
            this.lb_longpants2.Text = "Loose Fit High Jeans";
            // 
            // lb_longpants1
            // 
            this.lb_longpants1.AutoSize = true;
            this.lb_longpants1.Location = new System.Drawing.Point(4, 120);
            this.lb_longpants1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_longpants1.Name = "lb_longpants1";
            this.lb_longpants1.Size = new System.Drawing.Size(113, 13);
            this.lb_longpants1.TabIndex = 9;
            this.lb_longpants1.Text = "Skinny Cropped Jeans";
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(272, 7);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(102, 106);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox1.TabIndex = 8;
            this.pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox2.Image")));
            this.pictureBox2.Location = new System.Drawing.Point(139, 7);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(102, 106);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox2.TabIndex = 7;
            this.pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox3.Image")));
            this.pictureBox3.Location = new System.Drawing.Point(6, 7);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(102, 106);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox3.TabIndex = 6;
            this.pictureBox3.TabStop = false;
            // 
            // panel_shoes
            // 
            this.panel_shoes.Controls.Add(this.panel_jewelries);
            this.panel_shoes.Controls.Add(this.btn_addshoes3);
            this.panel_shoes.Controls.Add(this.btn_addshoes2);
            this.panel_shoes.Controls.Add(this.btn_addshoes1);
            this.panel_shoes.Controls.Add(this.lb_priceshoes3);
            this.panel_shoes.Controls.Add(this.lb_priceshoes2);
            this.panel_shoes.Controls.Add(this.lb_priceshoes1);
            this.panel_shoes.Controls.Add(this.lb_shoes3);
            this.panel_shoes.Controls.Add(this.lb_shoes2);
            this.panel_shoes.Controls.Add(this.lb_shoes1);
            this.panel_shoes.Controls.Add(this.pbox_shoes3);
            this.panel_shoes.Controls.Add(this.pbox_shoes2);
            this.panel_shoes.Controls.Add(this.pbox_shoes1);
            this.panel_shoes.Location = new System.Drawing.Point(0, 0);
            this.panel_shoes.Margin = new System.Windows.Forms.Padding(2);
            this.panel_shoes.Name = "panel_shoes";
            this.panel_shoes.Size = new System.Drawing.Size(388, 194);
            this.panel_shoes.TabIndex = 29;
            // 
            // btn_addshoes3
            // 
            this.btn_addshoes3.Location = new System.Drawing.Point(272, 166);
            this.btn_addshoes3.Margin = new System.Windows.Forms.Padding(2);
            this.btn_addshoes3.Name = "btn_addshoes3";
            this.btn_addshoes3.Size = new System.Drawing.Size(71, 20);
            this.btn_addshoes3.TabIndex = 17;
            this.btn_addshoes3.Text = "Add to Cart";
            this.btn_addshoes3.UseVisualStyleBackColor = true;
            this.btn_addshoes3.Click += new System.EventHandler(this.btn_addshoes3_Click);
            // 
            // btn_addshoes2
            // 
            this.btn_addshoes2.Location = new System.Drawing.Point(139, 166);
            this.btn_addshoes2.Margin = new System.Windows.Forms.Padding(2);
            this.btn_addshoes2.Name = "btn_addshoes2";
            this.btn_addshoes2.Size = new System.Drawing.Size(71, 20);
            this.btn_addshoes2.TabIndex = 16;
            this.btn_addshoes2.Text = "Add to Cart";
            this.btn_addshoes2.UseVisualStyleBackColor = true;
            this.btn_addshoes2.Click += new System.EventHandler(this.btn_addshoes2_Click);
            // 
            // btn_addshoes1
            // 
            this.btn_addshoes1.Location = new System.Drawing.Point(6, 166);
            this.btn_addshoes1.Margin = new System.Windows.Forms.Padding(2);
            this.btn_addshoes1.Name = "btn_addshoes1";
            this.btn_addshoes1.Size = new System.Drawing.Size(71, 20);
            this.btn_addshoes1.TabIndex = 15;
            this.btn_addshoes1.Text = "Add to Cart";
            this.btn_addshoes1.UseVisualStyleBackColor = true;
            this.btn_addshoes1.Click += new System.EventHandler(this.btn_addshoes1_Click);
            // 
            // lb_priceshoes3
            // 
            this.lb_priceshoes3.AutoSize = true;
            this.lb_priceshoes3.Location = new System.Drawing.Point(270, 140);
            this.lb_priceshoes3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_priceshoes3.Name = "lb_priceshoes3";
            this.lb_priceshoes3.Size = new System.Drawing.Size(90, 13);
            this.lb_priceshoes3.TabIndex = 14;
            this.lb_priceshoes3.Text = "Rp. 4.000.000,00";
            // 
            // lb_priceshoes2
            // 
            this.lb_priceshoes2.AutoSize = true;
            this.lb_priceshoes2.Location = new System.Drawing.Point(136, 140);
            this.lb_priceshoes2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_priceshoes2.Name = "lb_priceshoes2";
            this.lb_priceshoes2.Size = new System.Drawing.Size(90, 13);
            this.lb_priceshoes2.TabIndex = 13;
            this.lb_priceshoes2.Text = "Rp. 9.630.000,00";
            // 
            // lb_priceshoes1
            // 
            this.lb_priceshoes1.AutoSize = true;
            this.lb_priceshoes1.Location = new System.Drawing.Point(4, 140);
            this.lb_priceshoes1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_priceshoes1.Name = "lb_priceshoes1";
            this.lb_priceshoes1.Size = new System.Drawing.Size(90, 13);
            this.lb_priceshoes1.TabIndex = 12;
            this.lb_priceshoes1.Text = "Rp. 1.730.000,00";
            // 
            // lb_shoes3
            // 
            this.lb_shoes3.AutoSize = true;
            this.lb_shoes3.Location = new System.Drawing.Point(270, 120);
            this.lb_shoes3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_shoes3.Name = "lb_shoes3";
            this.lb_shoes3.Size = new System.Drawing.Size(89, 13);
            this.lb_shoes3.TabIndex = 11;
            this.lb_shoes3.Text = "Dr. Martens 1460";
            // 
            // lb_shoes2
            // 
            this.lb_shoes2.AutoSize = true;
            this.lb_shoes2.Location = new System.Drawing.Point(136, 120);
            this.lb_shoes2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_shoes2.Name = "lb_shoes2";
            this.lb_shoes2.Size = new System.Drawing.Size(127, 13);
            this.lb_shoes2.TabIndex = 10;
            this.lb_shoes2.Text = "Saint Laurent Tribute 105";
            // 
            // lb_shoes1
            // 
            this.lb_shoes1.AutoSize = true;
            this.lb_shoes1.Location = new System.Drawing.Point(4, 120);
            this.lb_shoes1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_shoes1.Name = "lb_shoes1";
            this.lb_shoes1.Size = new System.Drawing.Size(101, 13);
            this.lb_shoes1.TabIndex = 9;
            this.lb_shoes1.Text = "Nike Dunk Lo Twist";
            // 
            // pbox_shoes3
            // 
            this.pbox_shoes3.Image = ((System.Drawing.Image)(resources.GetObject("pbox_shoes3.Image")));
            this.pbox_shoes3.Location = new System.Drawing.Point(272, 7);
            this.pbox_shoes3.Margin = new System.Windows.Forms.Padding(2);
            this.pbox_shoes3.Name = "pbox_shoes3";
            this.pbox_shoes3.Size = new System.Drawing.Size(102, 106);
            this.pbox_shoes3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox_shoes3.TabIndex = 8;
            this.pbox_shoes3.TabStop = false;
            // 
            // pbox_shoes2
            // 
            this.pbox_shoes2.Image = ((System.Drawing.Image)(resources.GetObject("pbox_shoes2.Image")));
            this.pbox_shoes2.Location = new System.Drawing.Point(139, 7);
            this.pbox_shoes2.Margin = new System.Windows.Forms.Padding(2);
            this.pbox_shoes2.Name = "pbox_shoes2";
            this.pbox_shoes2.Size = new System.Drawing.Size(102, 106);
            this.pbox_shoes2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox_shoes2.TabIndex = 7;
            this.pbox_shoes2.TabStop = false;
            // 
            // pbox_shoes1
            // 
            this.pbox_shoes1.Image = ((System.Drawing.Image)(resources.GetObject("pbox_shoes1.Image")));
            this.pbox_shoes1.Location = new System.Drawing.Point(6, 7);
            this.pbox_shoes1.Margin = new System.Windows.Forms.Padding(2);
            this.pbox_shoes1.Name = "pbox_shoes1";
            this.pbox_shoes1.Size = new System.Drawing.Size(102, 106);
            this.pbox_shoes1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbox_shoes1.TabIndex = 6;
            this.pbox_shoes1.TabStop = false;
            // 
            // panel_jewelries
            // 
            this.panel_jewelries.Controls.Add(this.btn_addjewelries3);
            this.panel_jewelries.Controls.Add(this.btn_addjewelries2);
            this.panel_jewelries.Controls.Add(this.btn_addjewelries1);
            this.panel_jewelries.Controls.Add(this.lb_pricejewelries3);
            this.panel_jewelries.Controls.Add(this.lb_pricejewelries2);
            this.panel_jewelries.Controls.Add(this.lb_pricejewelries1);
            this.panel_jewelries.Controls.Add(this.lb_jewelries3);
            this.panel_jewelries.Controls.Add(this.lb_jewelries2);
            this.panel_jewelries.Controls.Add(this.lb_jewelries1);
            this.panel_jewelries.Controls.Add(this.pictureBox4);
            this.panel_jewelries.Controls.Add(this.pictureBox5);
            this.panel_jewelries.Controls.Add(this.pictureBox6);
            this.panel_jewelries.Location = new System.Drawing.Point(0, 0);
            this.panel_jewelries.Margin = new System.Windows.Forms.Padding(2);
            this.panel_jewelries.Name = "panel_jewelries";
            this.panel_jewelries.Size = new System.Drawing.Size(388, 194);
            this.panel_jewelries.TabIndex = 30;
            // 
            // btn_addjewelries3
            // 
            this.btn_addjewelries3.Location = new System.Drawing.Point(272, 166);
            this.btn_addjewelries3.Margin = new System.Windows.Forms.Padding(2);
            this.btn_addjewelries3.Name = "btn_addjewelries3";
            this.btn_addjewelries3.Size = new System.Drawing.Size(71, 20);
            this.btn_addjewelries3.TabIndex = 17;
            this.btn_addjewelries3.Text = "Add to Cart";
            this.btn_addjewelries3.UseVisualStyleBackColor = true;
            this.btn_addjewelries3.Click += new System.EventHandler(this.btn_addjewelries3_Click);
            // 
            // btn_addjewelries2
            // 
            this.btn_addjewelries2.Location = new System.Drawing.Point(139, 166);
            this.btn_addjewelries2.Margin = new System.Windows.Forms.Padding(2);
            this.btn_addjewelries2.Name = "btn_addjewelries2";
            this.btn_addjewelries2.Size = new System.Drawing.Size(71, 20);
            this.btn_addjewelries2.TabIndex = 16;
            this.btn_addjewelries2.Text = "Add to Cart";
            this.btn_addjewelries2.UseVisualStyleBackColor = true;
            this.btn_addjewelries2.Click += new System.EventHandler(this.btn_addjewelries2_Click);
            // 
            // btn_addjewelries1
            // 
            this.btn_addjewelries1.Location = new System.Drawing.Point(6, 166);
            this.btn_addjewelries1.Margin = new System.Windows.Forms.Padding(2);
            this.btn_addjewelries1.Name = "btn_addjewelries1";
            this.btn_addjewelries1.Size = new System.Drawing.Size(71, 20);
            this.btn_addjewelries1.TabIndex = 15;
            this.btn_addjewelries1.Text = "Add to Cart";
            this.btn_addjewelries1.UseVisualStyleBackColor = true;
            this.btn_addjewelries1.Click += new System.EventHandler(this.btn_addjewelries1_Click);
            // 
            // lb_pricejewelries3
            // 
            this.lb_pricejewelries3.AutoSize = true;
            this.lb_pricejewelries3.Location = new System.Drawing.Point(270, 140);
            this.lb_pricejewelries3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_pricejewelries3.Name = "lb_pricejewelries3";
            this.lb_pricejewelries3.Size = new System.Drawing.Size(90, 13);
            this.lb_pricejewelries3.TabIndex = 14;
            this.lb_pricejewelries3.Text = "Rp. 2.000.000,00";
            // 
            // lb_pricejewelries2
            // 
            this.lb_pricejewelries2.AutoSize = true;
            this.lb_pricejewelries2.Location = new System.Drawing.Point(136, 140);
            this.lb_pricejewelries2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_pricejewelries2.Name = "lb_pricejewelries2";
            this.lb_pricejewelries2.Size = new System.Drawing.Size(90, 13);
            this.lb_pricejewelries2.TabIndex = 13;
            this.lb_pricejewelries2.Text = "Rp. 1.700.000,00";
            // 
            // lb_pricejewelries1
            // 
            this.lb_pricejewelries1.AutoSize = true;
            this.lb_pricejewelries1.Location = new System.Drawing.Point(4, 140);
            this.lb_pricejewelries1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_pricejewelries1.Name = "lb_pricejewelries1";
            this.lb_pricejewelries1.Size = new System.Drawing.Size(90, 13);
            this.lb_pricejewelries1.TabIndex = 12;
            this.lb_pricejewelries1.Text = "Rp. 1.640.000,00";
            // 
            // lb_jewelries3
            // 
            this.lb_jewelries3.AutoSize = true;
            this.lb_jewelries3.Location = new System.Drawing.Point(270, 120);
            this.lb_jewelries3.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_jewelries3.Name = "lb_jewelries3";
            this.lb_jewelries3.Size = new System.Drawing.Size(94, 13);
            this.lb_jewelries3.TabIndex = 11;
            this.lb_jewelries3.Text = "Constella Oval Cut";
            // 
            // lb_jewelries2
            // 
            this.lb_jewelries2.AutoSize = true;
            this.lb_jewelries2.Location = new System.Drawing.Point(136, 120);
            this.lb_jewelries2.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_jewelries2.Name = "lb_jewelries2";
            this.lb_jewelries2.Size = new System.Drawing.Size(121, 13);
            this.lb_jewelries2.TabIndex = 10;
            this.lb_jewelries2.Text = "Pandora Elevated Heart";
            // 
            // lb_jewelries1
            // 
            this.lb_jewelries1.AutoSize = true;
            this.lb_jewelries1.Location = new System.Drawing.Point(4, 120);
            this.lb_jewelries1.Margin = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.lb_jewelries1.Name = "lb_jewelries1";
            this.lb_jewelries1.Size = new System.Drawing.Size(127, 13);
            this.lb_jewelries1.TabIndex = 9;
            this.lb_jewelries1.Text = "Daniel Wellington Lumine";
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox4.Image")));
            this.pictureBox4.Location = new System.Drawing.Point(272, 7);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(102, 106);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox4.TabIndex = 8;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox5.Image")));
            this.pictureBox5.Location = new System.Drawing.Point(139, 7);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(102, 106);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox5.TabIndex = 7;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox6.Image")));
            this.pictureBox6.Location = new System.Drawing.Point(6, 7);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(2);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(102, 106);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBox6.TabIndex = 6;
            this.pictureBox6.TabStop = false;
            // 
            // form_uniqme
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1027, 517);
            this.Controls.Add(this.panel_others);
            this.Controls.Add(this.panel_pants);
            this.Controls.Add(this.panel_tshirt);
            this.Controls.Add(this.btn_delete);
            this.Controls.Add(this.tb_total);
            this.Controls.Add(this.tb_subtotal);
            this.Controls.Add(this.lb_total);
            this.Controls.Add(this.lb_subtotal);
            this.Controls.Add(this.dgv_cart);
            this.Controls.Add(this.menustrip);
            this.MainMenuStrip = this.menustrip;
            this.Margin = new System.Windows.Forms.Padding(2);
            this.Name = "form_uniqme";
            this.Text = "UniqME";
            this.Load += new System.EventHandler(this.form_uniqme_Load);
            this.menustrip.ResumeLayout(false);
            this.menustrip.PerformLayout();
            this.panel_others.ResumeLayout(false);
            this.panel_others.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pb_others)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_cart)).EndInit();
            this.panel_shirt.ResumeLayout(false);
            this.panel_shirt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_shirt3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_shirt2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_shirt1)).EndInit();
            this.panel_tshirt.ResumeLayout(false);
            this.panel_tshirt.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_tshirt3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_tshirt2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_tshirt1)).EndInit();
            this.panel_pants.ResumeLayout(false);
            this.panel_pants.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_pants3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_pants2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_pants1)).EndInit();
            this.panel_longpants.ResumeLayout(false);
            this.panel_longpants.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            this.panel_shoes.ResumeLayout(false);
            this.panel_shoes.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_shoes3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_shoes2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_shoes1)).EndInit();
            this.panel_jewelries.ResumeLayout(false);
            this.panel_jewelries.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip menustrip;
        private System.Windows.Forms.ToolStripMenuItem tsm_topwear;
        private System.Windows.Forms.ToolStripMenuItem tShirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem shirtToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsm_bottomwear;
        private System.Windows.Forms.ToolStripMenuItem tsm_accessories;
        private System.Windows.Forms.ToolStripMenuItem pantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem longPantsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem tsm_others;
        private System.Windows.Forms.ToolStripMenuItem shoesToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem jewelriesToolStripMenuItem;
        private System.Windows.Forms.Panel panel_others;
        private System.Windows.Forms.TextBox tb_itemprice;
        private System.Windows.Forms.TextBox tb_itemname;
        private System.Windows.Forms.Button btn_addothers;
        private System.Windows.Forms.Button btn_upload;
        private System.Windows.Forms.Label lb_itemprice;
        private System.Windows.Forms.Label lb_itemname;
        private System.Windows.Forms.Label lb_upload;
        private System.Windows.Forms.PictureBox pb_others;
        private System.Windows.Forms.Button btn_delete;
        private System.Windows.Forms.TextBox tb_total;
        private System.Windows.Forms.TextBox tb_subtotal;
        private System.Windows.Forms.Label lb_total;
        private System.Windows.Forms.Label lb_subtotal;
        private System.Windows.Forms.DataGridView dgv_cart;
        private System.Windows.Forms.Panel panel_shirt;
        private System.Windows.Forms.Button btn_addshirt3;
        private System.Windows.Forms.Button btn_addshirt2;
        private System.Windows.Forms.Button btn_addshirt1;
        private System.Windows.Forms.Label lb_priceshirt3;
        private System.Windows.Forms.Label lb_priceshirt2;
        private System.Windows.Forms.Label lb_priceshirt1;
        private System.Windows.Forms.Label lb_shirt3;
        private System.Windows.Forms.Label lb_shirt2;
        private System.Windows.Forms.Label lb_shirt1;
        private System.Windows.Forms.PictureBox pbox_shirt3;
        private System.Windows.Forms.PictureBox pbox_shirt2;
        private System.Windows.Forms.PictureBox pbox_shirt1;
        private System.Windows.Forms.Panel panel_tshirt;
        private System.Windows.Forms.Button btn_addtshirt3;
        private System.Windows.Forms.Button btn_addtshirt2;
        private System.Windows.Forms.Button btn_addtshirt1;
        private System.Windows.Forms.Label lb_pricetshirt3;
        private System.Windows.Forms.Label lb_pricetshirt2;
        private System.Windows.Forms.Label lb_pricetshirt1;
        private System.Windows.Forms.Label lb_tshirt3;
        private System.Windows.Forms.Label lb_tshirt2;
        private System.Windows.Forms.Label lb_tshirt1;
        private System.Windows.Forms.PictureBox pbox_tshirt3;
        private System.Windows.Forms.PictureBox pbox_tshirt2;
        private System.Windows.Forms.PictureBox pbox_tshirt1;
        private System.Windows.Forms.Panel panel_pants;
        private System.Windows.Forms.Button btn_addpants3;
        private System.Windows.Forms.Button btn_addpants2;
        private System.Windows.Forms.Button btn_addpants1;
        private System.Windows.Forms.Label lb_pricepants3;
        private System.Windows.Forms.Label lb_pricepants2;
        private System.Windows.Forms.Label lb_pricepants1;
        private System.Windows.Forms.Label lb_pants3;
        private System.Windows.Forms.Label lb_pants2;
        private System.Windows.Forms.Label lb_pants1;
        private System.Windows.Forms.PictureBox pbox_pants3;
        private System.Windows.Forms.PictureBox pbox_pants2;
        private System.Windows.Forms.PictureBox pbox_pants1;
        private System.Windows.Forms.Panel panel_longpants;
        private System.Windows.Forms.Button btn_addlongpants3;
        private System.Windows.Forms.Button btn_addlongpants2;
        private System.Windows.Forms.Button btn_addlongpants1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label lb_longpants3;
        private System.Windows.Forms.Label lb_longpants2;
        private System.Windows.Forms.Label lb_longpants1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.Panel panel_shoes;
        private System.Windows.Forms.Button btn_addshoes3;
        private System.Windows.Forms.Button btn_addshoes2;
        private System.Windows.Forms.Button btn_addshoes1;
        private System.Windows.Forms.Label lb_priceshoes3;
        private System.Windows.Forms.Label lb_priceshoes2;
        private System.Windows.Forms.Label lb_priceshoes1;
        private System.Windows.Forms.Label lb_shoes3;
        private System.Windows.Forms.Label lb_shoes2;
        private System.Windows.Forms.Label lb_shoes1;
        private System.Windows.Forms.PictureBox pbox_shoes3;
        private System.Windows.Forms.PictureBox pbox_shoes2;
        private System.Windows.Forms.PictureBox pbox_shoes1;
        private System.Windows.Forms.Panel panel_jewelries;
        private System.Windows.Forms.Button btn_addjewelries3;
        private System.Windows.Forms.Button btn_addjewelries2;
        private System.Windows.Forms.Button btn_addjewelries1;
        private System.Windows.Forms.Label lb_pricejewelries3;
        private System.Windows.Forms.Label lb_pricejewelries2;
        private System.Windows.Forms.Label lb_pricejewelries1;
        private System.Windows.Forms.Label lb_jewelries3;
        private System.Windows.Forms.Label lb_jewelries2;
        private System.Windows.Forms.Label lb_jewelries1;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.PictureBox pictureBox6;
    }
}

